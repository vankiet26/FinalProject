package Data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ConnectDatabase {
	private static final String DB_ServerName = "LEVANKIET";
    private static final String DB_Login = "sa";
    private static final String DB_password = "123456789";
    private static final String DB_databaseName = "QUANLYVAYVONSINHVIEN";
    
    public static Connection getConnection() {

    try {
	Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
	String DB_URL = "jdbc:sqlserver://"+DB_ServerName +":1433"+";databaseName="+DB_databaseName+
			";encrypt = true;trustServerCertificate = true";
	return DriverManager.getConnection(DB_URL,DB_Login,DB_password);
   } catch (ClassNotFoundException e) {
	   e.printStackTrace();
   } catch (Exception e) {
	   e.printStackTrace();
     }
      return null;
   }
}