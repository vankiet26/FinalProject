package baitap;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.util.Properties;

public class DangNhap extends JFrame {
    private JTextField tfUsername;
    private JPasswordField pfPassword;
    private static final String DB_SERVER_NAME = "LEVANKIET";
    private static final String DB_DATABASE = "QUANLYVAYVONSINHVIEN"; 
    private static final String DB_LOGIN = "sa"; 
    private static final String DB_PASSWORD = "123456789"; 
    private JTextField txtVankietbank;
    
    public DangNhap() {
        setTitle("Đăng Nhập");
        setSize(660, 529);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(Color.WHITE);
        getContentPane().setLayout(null);
   
        JLabel lblUsername = new JLabel("Tên đăng nhập:");
        lblUsername.setFont(new Font("Tahoma", Font.PLAIN, 15));
        lblUsername.setBounds(166, 161, 200, 20);
        getContentPane().add(lblUsername);

        tfUsername = new JTextField();
        tfUsername.setBounds(166, 193, 325, 37);
        getContentPane().add(tfUsername);
   
        JLabel lblPassword = new JLabel("Mật khẩu:");
        lblPassword.setForeground(new Color(0, 0, 0));
        lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 15));
        lblPassword.setBounds(166, 250, 200, 20);
        getContentPane().add(lblPassword);

        pfPassword = new JPasswordField();
        pfPassword.setBounds(166, 280, 325, 37);
        getContentPane().add(pfPassword);
  
        JButton btnLogin = new JButton("Đăng Nhập");
        btnLogin.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnLogin.setBounds(166, 345, 138, 43);
        btnLogin.setBackground(new Color(66, 133, 244));
        btnLogin.setForeground(Color.RED);
        btnLogin.setFocusPainted(false);
        btnLogin.addActionListener(e -> kiemTraDangNhap());
        getContentPane().add(btnLogin);
  
        JButton btnRegister = new JButton("Đăng Ký");
        btnRegister.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnRegister.setBounds(353, 345, 138, 43);
        btnRegister.setBackground(new Color(25, 135, 84));
        btnRegister.setForeground(Color.GREEN);
        btnRegister.setFocusPainted(false);
        btnRegister.addActionListener(e -> chuyenSangDangKy());
        getContentPane().add(btnRegister);
        
        JLabel lblNewLabel_2 = new JLabel("");
        lblNewLabel_2.setIcon(new ImageIcon("C:\\Users\\KIET\\OneDrive\\Pictures\\Saved Pictures\\background-nhe-nhang-mau-xanh_085539289.jpg"));
        lblNewLabel_2.setBounds(-10, 0, 671, 504);
        getContentPane().add(lblNewLabel_2);
        
    }
    
    private void kiemTraDangNhap() {
        String username = tfUsername.getText();
        String password = new String(pfPassword.getPassword());
        
        if (validateLogin(username, password)) {
            JOptionPane.showMessageDialog(this, "Đăng nhập thành công!");
            this.dispose();
            new TrangChu().setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this, 
                "Sai tên đăng nhập hoặc mật khẩu!", 
                "Lỗi đăng nhập", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private boolean validateLogin(String username, String password) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = getConnection();
            
            String query = "SELECT * FROM Users WHERE username = ? AND password = ?";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);
            
            resultSet = preparedStatement.executeQuery();
            
            return resultSet.next(); 
            
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi kết nối cơ sở dữ liệu!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            return false;
        } finally {
            closeConnection(connection, preparedStatement, resultSet);
        }
    }

    private Connection getConnection() throws SQLException {
        try {
            String dbUrl = "jdbc:sqlserver://" + DB_SERVER_NAME + ":1433;" +
                           "databaseName=" + DB_DATABASE + ";" +
                           "encrypt=true;trustServerCertificate=true";
            return DriverManager.getConnection(dbUrl, DB_LOGIN, DB_PASSWORD);
        } catch (Exception e) {
            e.printStackTrace();
            throw new SQLException("Lỗi kết nối cơ sở dữ liệu: " + e.getMessage());
        }
    }

    private void closeConnection(Connection connection, PreparedStatement preparedStatement, ResultSet resultSet) {
        try {
            if (resultSet != null) {
                resultSet.close();
            }
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (connection != null) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void chuyenSangDangKy() {
        this.dispose();
        new DangKi().setVisible(true);
    }
    
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        SwingUtilities.invokeLater(() -> {
            new DangNhap().setVisible(true);
        });
    }
}
