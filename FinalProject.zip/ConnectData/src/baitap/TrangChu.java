package baitap;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import Data.ConnectDatabase;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class TrangChu extends JFrame {
    private JTable dataTable;
    private JScrollPane scrollPane;
    private JButton btnAdd, btnEdit, btnDelete, btnSearch;
    private JTextField searchField;
    private JLabel lblNewLabel;

    public TrangChu() {
        setTitle("Quản Lý Sinh Viên");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 804, 600);
        getContentPane().setLayout(null);

        JPanel searchPanel = new JPanel();
        searchPanel.setBounds(180, 10, 440, 40);
        searchPanel.setLayout(new FlowLayout(FlowLayout.LEFT));

        searchField = new JTextField(20);
        btnSearch = new JButton("Tìm kiếm");
        searchPanel.add(new JLabel("Tìm kiếm: "));
        searchPanel.add(searchField);
        searchPanel.add(btnSearch);
        getContentPane().add(searchPanel);

        dataTable = new JTable();
        scrollPane = new JScrollPane(dataTable);
        scrollPane.setBounds(180, 73, 616, 490);
        getContentPane().add(scrollPane);
        
        lblNewLabel = new JLabel("");
        lblNewLabel.setBounds(0, 0, 796, 563);
        lblNewLabel.setIcon(new ImageIcon("C:\\Users\\KIET\\OneDrive\\Pictures\\Saved Pictures\\desktop-wallpaper-artistic-rainbow-colors-splash-watercolor-backgrounds-2244174-vector-art-at-vecteezy-blue-yellow-white-color-splash.jpg"));
        getContentPane().add(lblNewLabel);
        
        JTextPane textPane = new JTextPane();
        textPane.setBounds(0, 0, 7, 19);
        getContentPane().add(textPane);
        
        JLabel lblNewLabel_1 = new JLabel("New label");
        lblNewLabel_1.setBounds(0, 447, 62, 31);
        getContentPane().add(lblNewLabel_1);

        setupMenuButtons();

        btnSearch.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                searchStudent();
            }
        });

        setVisible(true);
        showStudentInfo(); 
    }

    private void setupMenuButtons() {
        JButton[] menuButtons = new JButton[5]; 
        String[] buttonLabels = {
            "Thông Tin Sinh Viên", "Thêm Sinh Viên", 
            "Sửa Sinh Viên", "Xóa Sinh Viên", "Đăng Xuất"
        };

        for (int i = 0; i < menuButtons.length; i++) {
            menuButtons[i] = new JButton(buttonLabels[i]);
            menuButtons[i].setBounds(10, 10 + (i * 90), 160, 80);
            menuButtons[i].setFont(new Font("Tahoma", Font.PLAIN, 12));
            getContentPane().add(menuButtons[i]);
        }
        menuButtons[0].addActionListener(e -> showStudentInfo());
        menuButtons[1].addActionListener(e -> addStudent());
        menuButtons[2].addActionListener(e -> editStudent());
        menuButtons[3].addActionListener(e -> deleteStudent());
        menuButtons[4].addActionListener(e -> dispose());
    }

    private void searchStudent() {
        String searchText = searchField.getText().trim();
        if (searchText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập thông tin cần tìm!");
            return;
        }

        try (Connection conn = ConnectDatabase.getConnection()) {
            String query = "SELECT * FROM dbo.SinhVien WHERE hoTen LIKE ? OR id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, "%" + searchText + "%");
            stmt.setString(2, searchText);

            ResultSet rs = stmt.executeQuery();
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();

            DefaultTableModel model = new DefaultTableModel();
            for (int i = 1; i <= columnCount; i++) {
                model.addColumn(metaData.getColumnName(i));
            }

            if (rs.next()) {
                do {
                    Object[] row = new Object[columnCount];
                    for (int i = 1; i <= columnCount; i++) {
                        row[i-1] = rs.getObject(i);
                    }
                    model.addRow(row);
                } while (rs.next());
                dataTable.setModel(model);
            } else {
                JOptionPane.showMessageDialog(this, "Không tìm thấy sinh viên với thông tin: " + searchText);
                showStudentInfo();
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage());
        }
    }

    private void showStudentInfo() {
        try (Connection conn = ConnectDatabase.getConnection()) {
            if (conn != null) {
                String query = "SELECT * FROM dbo.SinhVien";
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(query);

                ResultSetMetaData metaData = rs.getMetaData();
                int columnCount = metaData.getColumnCount();

                DefaultTableModel model = new DefaultTableModel();

                for (int i = 1; i <= columnCount; i++) {
                    model.addColumn(metaData.getColumnName(i));
                }

                while (rs.next()) {
                    Object[] row = new Object[columnCount];
                    for (int i = 1; i <= columnCount; i++) {
                        row[i-1] = rs.getObject(i);
                    }
                    model.addRow(row);
                }

                dataTable.setModel(model);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage());
        }
    }

    private void addStudent() {
        JTextField hoTenField = new JTextField();
        JTextField ngaySinhField = new JTextField();
        JTextField soCMNDField = new JTextField();
        JTextField diaChiField = new JTextField();
        JTextField soTienVayField = new JTextField();
        Object[] fields = {
            "Họ tên:", hoTenField,
            "Ngày sinh:", ngaySinhField,
            "Số CMND:", soCMNDField,
            "Địa chỉ:", diaChiField,
            "Số tiền vay:", soTienVayField
        };
        int result = JOptionPane.showConfirmDialog(null, fields, 
                "Thêm Sinh Viên", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try (Connection conn = ConnectDatabase.getConnection()) {
                String query = "INSERT INTO dbo.SinhVien (hoTen, ngaySinh, soCMND, diaChi, soTienVay) VALUES (?, ?, ?, ?, ?)";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setString(1, hoTenField.getText());
                stmt.setString(2, ngaySinhField.getText());
                stmt.setString(3, soCMNDField.getText());
                stmt.setString(4, diaChiField.getText());
                stmt.setString(5, soTienVayField.getText());
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Thêm sinh viên thành công!");
                showStudentInfo();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage());
            }
        }
    }

    private void editStudent() {
        int selectedRow = dataTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn sinh viên cần sửa!");
            return;
        }

        String id = dataTable.getValueAt(selectedRow, 0).toString();

        JTextField hoTenField = new JTextField(dataTable.getValueAt(selectedRow, 1).toString());
        JTextField ngaySinhField = new JTextField(dataTable.getValueAt(selectedRow, 2).toString());
        JTextField soCMNDField = new JTextField(dataTable.getValueAt(selectedRow, 3).toString());
        JTextField diaChiField = new JTextField(dataTable.getValueAt(selectedRow, 4).toString());
        JTextField soTienVayField = new JTextField(dataTable.getValueAt(selectedRow, 5).toString());

        Object[] fields = {
            "Họ tên:", hoTenField,
            "Ngày sinh:", ngaySinhField,
            "Số CMND:", soCMNDField,
            "Địa chỉ:", diaChiField,
            "Số tiền vay:", soTienVayField
        };

        int result = JOptionPane.showConfirmDialog(null, fields, 
                "Sửa Thông Tin Sinh Viên", JOptionPane.OK_CANCEL_OPTION);

        if (result == JOptionPane.OK_OPTION) {
            try (Connection conn = ConnectDatabase.getConnection()) {
                String query = "UPDATE dbo.SinhVien SET hoTen=?, ngaySinh=?, soCMND=?, diaChi=?, soTienVay=? WHERE id=?";
                PreparedStatement stmt = conn.prepareStatement(query);

                stmt.setString(1, hoTenField.getText());
                stmt.setString(2, ngaySinhField.getText());
                stmt.setString(3, soCMNDField.getText());
                stmt.setString(4, diaChiField.getText());
                stmt.setString(5, soTienVayField.getText());
                stmt.setInt(6, Integer.parseInt(id));

                stmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Cập nhật thông tin thành công!");
                showStudentInfo();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage());
            }
        }
    }

    private void deleteStudent() {
        int selectedRow = dataTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn sinh viên cần xóa!");
            return;
        }

        String id = dataTable.getValueAt(selectedRow, 0).toString();
        int confirm = JOptionPane.showConfirmDialog(this,
                "Bạn có chắc chắn muốn xóa sinh viên này?",
                "Xác nhận xóa",
                JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection conn = ConnectDatabase.getConnection()) {
                String query = "DELETE FROM dbo.SinhVien WHERE id=?";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setInt(1, Integer.parseInt(id));

                stmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Xóa sinh viên thành công!");
                showStudentInfo();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage());
            }
        }
    }
}
