package baitap;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class DangKi extends JFrame {
    private JTextField tfUsername;
    private JPasswordField pfPassword;
    private JPasswordField pfConfirmPassword;
    private static final String DB_SERVER_NAME = "LEVANKIET"; 
    private static final String DB_DATABASE = "QUANLYVAYVONSINHVIEN"; 
    private static final String DB_LOGIN = "sa"; 
    private static final String DB_PASSWORD = "123456789"; 

    public DangKi() {
        setTitle("Đăng Ký Tài Khoản");
        setSize(710, 604);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setLayout(null);
        getContentPane().setBackground(Color.WHITE);

        JLabel lblUsername = new JLabel("Tên đăng nhập:");
        lblUsername.setFont(new Font("Tahoma", Font.PLAIN, 15));
        lblUsername.setBounds(208, 186, 200, 20);
        getContentPane().add(lblUsername);

        tfUsername = new JTextField();
        tfUsername.setBounds(208, 216, 319, 35);
        getContentPane().add(tfUsername);

        JLabel lblPassword = new JLabel("Mật khẩu:");
        lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 15));
        lblPassword.setBounds(208, 261, 200, 20);
        getContentPane().add(lblPassword);

        pfPassword = new JPasswordField();
        pfPassword.setBounds(208, 291, 319, 35);
        getContentPane().add(pfPassword);

        JLabel lblConfirmPassword = new JLabel("Xác nhận mật khẩu:");
        lblConfirmPassword.setFont(new Font("Tahoma", Font.PLAIN, 15));
        lblConfirmPassword.setBounds(208, 336, 200, 20);
        getContentPane().add(lblConfirmPassword);

        pfConfirmPassword = new JPasswordField();
        pfConfirmPassword.setBounds(208, 366, 319, 35);
        getContentPane().add(pfConfirmPassword);

        JButton btnRegister = new JButton("Đăng Ký");
        btnRegister.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnRegister.setBounds(209, 437, 123, 55);
        btnRegister.setBackground(new Color(25, 135, 84));
        btnRegister.setForeground(Color.GREEN);
        btnRegister.setFocusPainted(false);
        btnRegister.addActionListener(e -> dangKyTaiKhoan());
        getContentPane().add(btnRegister);

        JButton btnBack = new JButton("Quay Lại");
        btnBack.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnBack.setBounds(398, 437, 129, 55);
        btnBack.setBackground(new Color(108, 117, 125));
        btnBack.setForeground(Color.PINK);
        btnBack.setFocusPainted(false);
        btnBack.addActionListener(e -> quayLaiDangNhap());
        getContentPane().add(btnBack);

        JLabel lblNewLabel = new JLabel("");
        lblNewLabel.setIcon(new ImageIcon("C:\\Users\\KIET\\OneDrive\\Pictures\\Saved Pictures\\anh2.jpg"));
        lblNewLabel.setBounds(0, 0, 696, 567);
        getContentPane().add(lblNewLabel);
    }

    private void dangKyTaiKhoan() {
        String username = tfUsername.getText();
        String password = new String(pfPassword.getPassword());
        String confirmPassword = new String(pfConfirmPassword.getPassword());

        if (username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng điền đầy đủ thông tin!");
            return;
        }

        if (!password.equals(confirmPassword)) {
            JOptionPane.showMessageDialog(this, "Mật khẩu xác nhận không khớp!");
            return;
        }

        if (checkIfUserExists(username)) {
            JOptionPane.showMessageDialog(this, "Tên đăng nhập đã tồn tại!");
            return;
        }

        boolean success = registerUserInDatabase(username, password);
        if (success) {
            JOptionPane.showMessageDialog(this, "Đăng ký thành công!");
            quayLaiDangNhap();
        } else {
            JOptionPane.showMessageDialog(this, "Lỗi đăng ký, vui lòng thử lại!", "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private boolean checkIfUserExists(String username) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = getConnection();
            String query = "SELECT * FROM Users WHERE username = ?";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, username);
            resultSet = preparedStatement.executeQuery();

            return resultSet.next(); 
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            closeConnection(connection, preparedStatement, resultSet);
        }
    }

    private boolean registerUserInDatabase(String username, String password) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            connection = getConnection();
            String query = "INSERT INTO Users (username, password) VALUES (?, ?)";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);

            int rowsInserted = preparedStatement.executeUpdate();
            return rowsInserted > 0; 
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            closeConnection(connection, preparedStatement, null);
        }
    }

    private Connection getConnection() throws SQLException {
        try {
            String dbUrl = "jdbc:sqlserver://" + DB_SERVER_NAME + ":1433;" +
                           "databaseName=" + DB_DATABASE + ";" +
                           "encrypt=true;trustServerCertificate=true";
            return DriverManager.getConnection(dbUrl, DB_LOGIN, DB_PASSWORD);
        } catch (Exception e) {
            e.printStackTrace();
            throw new SQLException("Lỗi kết nối cơ sở dữ liệu: " + e.getMessage());
        }
    }

    private void closeConnection(Connection connection, PreparedStatement preparedStatement, ResultSet resultSet) {
        try {
            if (resultSet != null) {
                resultSet.close();
            }
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (connection != null) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void quayLaiDangNhap() {
        this.dispose();
        new DangNhap().setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new DangKi().setVisible(true);
        });
    }
}
