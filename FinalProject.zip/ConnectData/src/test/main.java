package test;
import java.sql.Connection;
import Data.ConnectDatabase;
public class main {

	public static void main(String[] args) {
		Connection con = ConnectDatabase.getConnection();
		if(con==null) {
			System.out.println("that bai");
		} else {
			System.out.println("thanh cong");
		}

	}

}
